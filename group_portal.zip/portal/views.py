from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import CreateView
from django.urls import reverse_lazy

from .forms import SignUpForm
from .models import Student, NewsPost, Lesson, Material


def home(request):
    news = NewsPost.objects.all()[:5]
    lessons_today = Lesson.objects.all()
    context = {
        'news': news,
        'students_count': Student.objects.count(),
        'materials_count': Material.objects.count(),
    }
    return render(request, 'portal/home.html', context)


def news_list(request):
    news = NewsPost.objects.all()
    return render(request, 'portal/news_list.html', {'news': news})


def news_detail(request, pk):
    post = get_object_or_404(NewsPost, pk=pk)
    return render(request, 'portal/news_detail.html', {'post': post})


def schedule(request):
    lessons = Lesson.objects.all()
    lessons_by_day = {day_num: [] for day_num, _ in Lesson.DAY_CHOICES}
    for lesson in lessons:
        lessons_by_day[lesson.day_of_week].append(lesson)

    days = [
        {'name': day_name, 'lessons': lessons_by_day[day_num]}
        for day_num, day_name in Lesson.DAY_CHOICES
    ]
    return render(request, 'portal/schedule.html', {'days': days})


def members(request):
    students = Student.objects.all()
    return render(request, 'portal/members.html', {'students': students})


@login_required
def materials(request):
    files = Material.objects.all()
    return render(request, 'portal/materials.html', {'materials': files})


class SignUpView(CreateView):
    form_class = SignUpForm
    template_name = 'portal/signup.html'
    success_url = reverse_lazy('home')

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)
        return response


class PortalLoginView(LoginView):
    template_name = 'portal/login.html'


class PortalLogoutView(LogoutView):
    next_page = 'home'
