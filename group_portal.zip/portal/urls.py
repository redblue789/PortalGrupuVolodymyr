from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('news/', views.news_list, name='news_list'),
    path('news/<int:pk>/', views.news_detail, name='news_detail'),
    path('schedule/', views.schedule, name='schedule'),
    path('members/', views.members, name='members'),
    path('materials/', views.materials, name='materials'),
    path('signup/', views.SignUpView.as_view(), name='signup'),
    path('login/', views.PortalLoginView.as_view(), name='login'),
    path('logout/', views.PortalLogoutView.as_view(), name='logout'),
]
