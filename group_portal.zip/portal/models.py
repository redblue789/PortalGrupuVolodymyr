from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse


class Student(models.Model):
    """Студент групи (не обов'язково пов'язаний з обліковим записом)."""

    ROLE_CHOICES = [
        ('starosta', 'Староста'),
        ('zastupnyk', 'Заступник старости'),
        ('student', 'Студент'),
    ]

    full_name = models.CharField('ПІБ', max_length=150)
    role = models.CharField('Роль у групі', max_length=20, choices=ROLE_CHOICES, default='student')
    email = models.EmailField('Email', blank=True)
    phone = models.CharField('Телефон', max_length=30, blank=True)
    photo = models.ImageField('Фото', upload_to='students/', blank=True, null=True)
    bio = models.TextField('Про себе', blank=True)
    user = models.OneToOneField(User, on_delete=models.SET_NULL, null=True, blank=True,
                                 verbose_name='Обліковий запис', related_name='student_profile')

    class Meta:
        verbose_name = 'Студент'
        verbose_name_plural = 'Студенти'
        ordering = ['full_name']

    def __str__(self):
        return self.full_name


class NewsPost(models.Model):
    """Новина / оголошення групи."""

    title = models.CharField('Заголовок', max_length=200)
    content = models.TextField('Текст')
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='Автор')
    created_at = models.DateTimeField('Дата публікації', auto_now_add=True)
    is_pinned = models.BooleanField('Закріпити', default=False)

    class Meta:
        verbose_name = 'Новина'
        verbose_name_plural = 'Новини'
        ordering = ['-is_pinned', '-created_at']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('news_detail', args=[self.pk])


class Lesson(models.Model):
    """Одна пара в розкладі занять."""

    DAY_CHOICES = [
        (1, 'Понеділок'),
        (2, 'Вівторок'),
        (3, 'Середа'),
        (4, "Четвер"),
        (5, "П'ятниця"),
        (6, 'Субота'),
    ]

    day_of_week = models.PositiveSmallIntegerField('День тижня', choices=DAY_CHOICES)
    order = models.PositiveSmallIntegerField('Номер пари', default=1)
    subject = models.CharField('Предмет', max_length=150)
    teacher = models.CharField('Викладач', max_length=150, blank=True)
    room = models.CharField('Аудиторія', max_length=50, blank=True)
    time_start = models.TimeField('Початок')
    time_end = models.TimeField('Кінець')
    is_online = models.BooleanField('Онлайн', default=False)

    class Meta:
        verbose_name = 'Заняття'
        verbose_name_plural = 'Розклад занять'
        ordering = ['day_of_week', 'order']

    def __str__(self):
        return f'{self.get_day_of_week_display()}, пара {self.order}: {self.subject}'


class Material(models.Model):
    """Навчальний матеріал / файл для групи."""

    title = models.CharField('Назва', max_length=200)
    description = models.TextField('Опис', blank=True)
    file = models.FileField('Файл', upload_to='materials/')
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='Завантажив')
    uploaded_at = models.DateTimeField('Дата завантаження', auto_now_add=True)

    class Meta:
        verbose_name = 'Матеріал'
        verbose_name_plural = 'Матеріали'
        ordering = ['-uploaded_at']

    def __str__(self):
        return self.title
