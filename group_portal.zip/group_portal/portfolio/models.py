from django.conf import settings
from django.db import models


class PortfolioItem(models.Model):
    """Проект учня у портфоліо: скріншот, посилання та/або файл."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='portfolio_items')
    title = models.CharField('Назва проекту', max_length=200)
    description = models.TextField('Опис', blank=True)
    screenshot = models.ImageField('Скріншот', upload_to='portfolio/screenshots/', blank=True, null=True)
    link = models.URLField('Посилання', blank=True)
    file = models.FileField('Файл', upload_to='portfolio/files/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Проект портфоліо'
        verbose_name_plural = 'Портфоліо'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.title} ({self.user})'
