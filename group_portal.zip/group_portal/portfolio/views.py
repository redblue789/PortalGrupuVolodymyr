from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from core.mixins import OwnerOrModeratorMixin

from .forms import PortfolioItemForm
from .models import PortfolioItem


class PortfolioListView(ListView):
    model = PortfolioItem
    template_name = 'portfolio/list.html'
    context_object_name = 'items'
    paginate_by = 12


class PortfolioDetailView(DetailView):
    model = PortfolioItem
    template_name = 'portfolio/detail.html'
    context_object_name = 'item'


class PortfolioCreateView(LoginRequiredMixin, CreateView):
    model = PortfolioItem
    form_class = PortfolioItemForm
    template_name = 'portfolio/form.html'
    success_url = reverse_lazy('portfolio:list')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class PortfolioUpdateView(OwnerOrModeratorMixin, UpdateView):
    model = PortfolioItem
    form_class = PortfolioItemForm
    template_name = 'portfolio/form.html'
    success_url = reverse_lazy('portfolio:list')


class PortfolioDeleteView(OwnerOrModeratorMixin, DeleteView):
    model = PortfolioItem
    template_name = 'portfolio/confirm_delete.html'
    success_url = reverse_lazy('portfolio:list')
