from django.urls import path

from . import views

app_name = 'gallery'

urlpatterns = [
    path('', views.GalleryListView.as_view(), name='list'),
    path('add/', views.GalleryCreateView.as_view(), name='add'),
    path('moderation/', views.GalleryModerationListView.as_view(), name='moderation'),
    path('<int:pk>/approve/', views.approve_item, name='approve'),
    path('<int:pk>/delete/', views.GalleryDeleteView.as_view(), name='delete'),
]
