import re

from django.conf import settings
from django.db import models


class GalleryItem(models.Model):
    """Фото/відео учнів. Додати може будь-який користувач, але матеріал
    з'являється у публічній галереї лише після перевірки модератором/адміном."""

    PHOTO = 'photo'
    VIDEO = 'video'
    TYPE_CHOICES = [(PHOTO, 'Фото'), (VIDEO, 'Відео')]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='gallery_items')
    media_type = models.CharField('Тип', max_length=10, choices=TYPE_CHOICES, default=PHOTO)
    image = models.ImageField('Фото', upload_to='gallery/photos/', blank=True, null=True)
    video_url = models.URLField('Посилання на відео', blank=True)
    caption = models.CharField('Підпис', max_length=200, blank=True)
    is_approved = models.BooleanField('Затверджено', default=False)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_gallery_items'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Медіа галереї'
        verbose_name_plural = 'Галерея'
        ordering = ['-created_at']

    def __str__(self):
        return self.caption or f'{self.get_media_type_display()} від {self.user}'

    @property
    def embed_url(self):
        """Перетворює звичайне посилання YouTube на URL для вбудованого плеєра."""
        if not self.video_url:
            return None
        patterns = [r'youtu\.be/([\w-]+)', r'youtube\.com/watch\?v=([\w-]+)', r'youtube\.com/embed/([\w-]+)']
        for pattern in patterns:
            match = re.search(pattern, self.video_url)
            if match:
                return f'https://www.youtube.com/embed/{match.group(1)}'
        return self.video_url
