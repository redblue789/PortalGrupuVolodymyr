from django import forms

from .models import GalleryItem


class GalleryItemForm(forms.ModelForm):
    class Meta:
        model = GalleryItem
        fields = ('media_type', 'image', 'video_url', 'caption')

    def clean(self):
        cleaned = super().clean()
        m_type = cleaned.get('media_type')
        if m_type == GalleryItem.PHOTO and not cleaned.get('image'):
            self.add_error('image', 'Додайте файл фото.')
        if m_type == GalleryItem.VIDEO and not cleaned.get('video_url'):
            self.add_error('video_url', 'Вкажіть посилання на відео.')
        return cleaned
