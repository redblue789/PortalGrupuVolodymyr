from django.contrib import admin

from .models import GalleryItem


@admin.register(GalleryItem)
class GalleryItemAdmin(admin.ModelAdmin):
    list_display = ('user', 'media_type', 'is_approved', 'created_at')
    list_filter = ('is_approved', 'media_type')
    actions = ['approve_items']

    def approve_items(self, request, queryset):
        queryset.update(is_approved=True)
    approve_items.short_description = 'Затвердити вибрані матеріали'
