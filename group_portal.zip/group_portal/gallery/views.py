from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView

from core.mixins import ModeratorRequiredMixin, OwnerOrModeratorMixin

from .forms import GalleryItemForm
from .models import GalleryItem


class GalleryListView(ListView):
    """Публічна галерея — лише затверджені матеріали."""

    model = GalleryItem
    template_name = 'gallery/list.html'
    context_object_name = 'items'
    paginate_by = 12

    def get_queryset(self):
        return GalleryItem.objects.filter(is_approved=True)


class GalleryCreateView(LoginRequiredMixin, CreateView):
    model = GalleryItem
    form_class = GalleryItemForm
    template_name = 'gallery/form.html'
    success_url = reverse_lazy('gallery:list')

    def form_valid(self, form):
        form.instance.user = self.request.user
        messages.success(self.request, 'Дякуємо! Матеріал додано та очікує на перевірку модератором.')
        return super().form_valid(form)


class GalleryModerationListView(ModeratorRequiredMixin, ListView):
    """Черга матеріалів, що очікують на перевірку."""

    model = GalleryItem
    template_name = 'gallery/moderation_list.html'
    context_object_name = 'items'

    def get_queryset(self):
        return GalleryItem.objects.filter(is_approved=False)


class GalleryDeleteView(OwnerOrModeratorMixin, DeleteView):
    model = GalleryItem
    template_name = 'gallery/confirm_delete.html'
    success_url = reverse_lazy('gallery:list')


@login_required
def approve_item(request, pk):
    item = get_object_or_404(GalleryItem, pk=pk)
    profile = getattr(request.user, 'profile', None)
    if not (profile and profile.is_moderator):
        messages.error(request, 'Недостатньо прав.')
        return redirect('gallery:list')
    item.is_approved = True
    item.approved_by = request.user
    item.save()
    messages.success(request, 'Матеріал затверджено та опубліковано в галереї.')
    return redirect('gallery:moderation')
