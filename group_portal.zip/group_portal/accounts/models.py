from django.conf import settings
from django.db import models


class Profile(models.Model):
    """Розширення стандартного User: додає роль доступу
    (користувач / модератор / адміністратор) та особисті дані."""

    ROLE_USER = 'user'
    ROLE_MODERATOR = 'moderator'
    ROLE_ADMIN = 'admin'
    ROLE_CHOICES = [
        (ROLE_USER, 'Користувач'),
        (ROLE_MODERATOR, 'Модератор'),
        (ROLE_ADMIN, 'Адміністратор'),
    ]

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile'
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_USER)
    bio = models.TextField('Про себе', blank=True)
    avatar = models.ImageField('Аватар', upload_to='avatars/', blank=True, null=True)

    class Meta:
        verbose_name = 'Профіль'
        verbose_name_plural = 'Профілі'

    def __str__(self):
        return f'{self.user.username} ({self.get_role_display()})'

    @property
    def is_moderator(self):
        return self.role in (self.ROLE_MODERATOR, self.ROLE_ADMIN)

    @property
    def is_admin_role(self):
        return self.role == self.ROLE_ADMIN
