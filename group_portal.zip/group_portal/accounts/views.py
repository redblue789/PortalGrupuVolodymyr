from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView

from .forms import ProfileUpdateForm, RegisterForm, UserUpdateForm
from .models import Profile


class RegisterView(CreateView):
    """Реєстрація нового користувача."""

    form_class = RegisterForm
    template_name = 'accounts/register.html'
    success_url = reverse_lazy('accounts:login')

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, 'Реєстрація успішна! Тепер увійдіть у свій акаунт.')
        return response


class ProfileDetailView(LoginRequiredMixin, DetailView):
    """Перегляд профілю (свого або іншого користувача)."""

    model = Profile
    template_name = 'accounts/profile_detail.html'
    context_object_name = 'profile'

    def get_object(self):
        username = self.kwargs.get('username')
        if username:
            return Profile.objects.select_related('user').get(user__username=username)
        return self.request.user.profile


@login_required
def profile_update(request):
    """Редагування власних особистих даних (ім'я, пошта, аватар, про себе)."""
    profile = request.user.profile
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfileUpdateForm(request.POST, request.FILES, instance=profile)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, 'Профіль оновлено.')
            return redirect('accounts:profile')
    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=profile)
    return render(request, 'accounts/profile_edit.html', {'u_form': u_form, 'p_form': p_form})
