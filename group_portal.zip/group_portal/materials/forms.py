from django import forms

from .models import Material


class MaterialForm(forms.ModelForm):
    class Meta:
        model = Material
        fields = ('title', 'description', 'material_type', 'file', 'image', 'url')

    def clean(self):
        cleaned = super().clean()
        m_type = cleaned.get('material_type')
        if m_type == Material.FILE and not cleaned.get('file'):
            self.add_error('file', 'Оберіть файл для завантаження.')
        if m_type == Material.IMAGE and not cleaned.get('image'):
            self.add_error('image', 'Оберіть картинку для завантаження.')
        if m_type in (Material.LINK, Material.YOUTUBE) and not cleaned.get('url'):
            self.add_error('url', 'Вкажіть посилання.')
        return cleaned
