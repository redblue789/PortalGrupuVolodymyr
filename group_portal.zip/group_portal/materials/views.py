from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from core.mixins import ModeratorRequiredMixin

from .forms import MaterialForm
from .models import Material


class MaterialListView(ListView):
    model = Material
    template_name = 'materials/list.html'
    context_object_name = 'materials'
    paginate_by = 20


class MaterialCreateView(ModeratorRequiredMixin, CreateView):
    model = Material
    form_class = MaterialForm
    template_name = 'materials/form.html'
    success_url = reverse_lazy('materials:list')

    def form_valid(self, form):
        form.instance.uploaded_by = self.request.user
        return super().form_valid(form)


class MaterialUpdateView(ModeratorRequiredMixin, UpdateView):
    model = Material
    form_class = MaterialForm
    template_name = 'materials/form.html'
    success_url = reverse_lazy('materials:list')


class MaterialDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Material
    template_name = 'materials/confirm_delete.html'
    success_url = reverse_lazy('materials:list')
