from django.urls import path

from . import views

app_name = 'materials'

urlpatterns = [
    path('', views.MaterialListView.as_view(), name='list'),
    path('add/', views.MaterialCreateView.as_view(), name='add'),
    path('<int:pk>/edit/', views.MaterialUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', views.MaterialDeleteView.as_view(), name='delete'),
]
