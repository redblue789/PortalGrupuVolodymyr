import re

from django.conf import settings
from django.db import models


class Material(models.Model):
    """Корисний матеріал: файл, картинка, посилання або відео з YouTube."""

    FILE = 'file'
    IMAGE = 'image'
    LINK = 'link'
    YOUTUBE = 'youtube'
    TYPE_CHOICES = [
        (FILE, 'Файл'),
        (IMAGE, 'Картинка'),
        (LINK, 'Посилання'),
        (YOUTUBE, 'YouTube відео'),
    ]

    title = models.CharField('Назва', max_length=200)
    description = models.TextField('Опис', blank=True)
    material_type = models.CharField('Тип', max_length=10, choices=TYPE_CHOICES)
    file = models.FileField('Файл', upload_to='materials/files/', blank=True, null=True)
    image = models.ImageField('Картинка', upload_to='materials/images/', blank=True, null=True)
    url = models.URLField('Посилання', blank=True)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='materials'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Матеріал'
        verbose_name_plural = 'Матеріали'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    @property
    def youtube_embed_id(self):
        if self.material_type != self.YOUTUBE or not self.url:
            return None
        patterns = [
            r'youtu\.be/([\w-]+)',
            r'youtube\.com/watch\?v=([\w-]+)',
            r'youtube\.com/embed/([\w-]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, self.url)
            if match:
                return match.group(1)
        return None
