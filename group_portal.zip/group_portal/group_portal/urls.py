from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),
    path('accounts/', include('accounts.urls')),
    path('forum/', include('forum.urls')),
    path('diary/', include('diary.urls')),
    path('events/', include('events.urls')),
    path('polls/', include('polls_app.urls')),
    path('voting/', include('voting.urls')),
    path('announcements/', include('announcements.urls')),
    path('materials/', include('materials.urls')),
    path('portfolio/', include('portfolio.urls')),
    path('gallery/', include('gallery.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
