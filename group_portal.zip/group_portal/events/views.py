import calendar
from collections import defaultdict

from django.urls import reverse_lazy
from django.utils import timezone
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from core.mixins import ModeratorRequiredMixin

from .forms import EventForm
from .models import Event


class EventListView(ListView):
    model = Event
    template_name = 'events/event_list.html'
    context_object_name = 'events'

    def get_queryset(self):
        return Event.objects.filter(start__gte=timezone.now())


class EventDetailView(DetailView):
    model = Event
    template_name = 'events/event_detail.html'
    context_object_name = 'event'


class EventCreateView(ModeratorRequiredMixin, CreateView):
    model = Event
    form_class = EventForm
    template_name = 'events/event_form.html'
    success_url = reverse_lazy('events:list')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)


class EventUpdateView(ModeratorRequiredMixin, UpdateView):
    model = Event
    form_class = EventForm
    template_name = 'events/event_form.html'
    success_url = reverse_lazy('events:list')


class EventDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Event
    template_name = 'events/confirm_delete.html'
    success_url = reverse_lazy('events:list')


class CalendarView(ListView):
    """Простий календар подій на місяць."""

    model = Event
    template_name = 'events/calendar.html'
    context_object_name = 'events'

    def get_queryset(self):
        year = int(self.request.GET.get('year', timezone.now().year))
        month = int(self.request.GET.get('month', timezone.now().month))
        self.year, self.month = year, month
        return Event.objects.filter(start__year=year, start__month=month)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        cal = calendar.Calendar(firstweekday=0)
        days_by_date = defaultdict(list)
        for event in ctx['events']:
            days_by_date[event.start.day].append(event)

        weeks = []
        for week in cal.monthdayscalendar(self.year, self.month):
            weeks.append([(day, days_by_date.get(day, [])) if day != 0 else (0, []) for day in week])

        prev_month = self.month - 1 or 12
        prev_year = self.year - 1 if self.month == 1 else self.year
        next_month = self.month + 1 if self.month < 12 else 1
        next_year = self.year + 1 if self.month == 12 else self.year

        ctx.update({
            'weeks': weeks,
            'month_name': calendar.month_name[self.month],
            'year': self.year,
            'month': self.month,
            'prev_month': prev_month, 'prev_year': prev_year,
            'next_month': next_month, 'next_year': next_year,
        })
        return ctx
