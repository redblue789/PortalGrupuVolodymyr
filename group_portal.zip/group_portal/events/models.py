from django.conf import settings
from django.db import models
from django.urls import reverse


class Event(models.Model):
    """Подія групи, що відображається у списку подій та у календарі."""

    title = models.CharField('Назва', max_length=200)
    description = models.TextField('Опис', blank=True)
    location = models.CharField('Місце', max_length=200, blank=True)
    start = models.DateTimeField('Початок')
    end = models.DateTimeField('Кінець', null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='events_created'
    )

    class Meta:
        verbose_name = 'Подія'
        verbose_name_plural = 'Події'
        ordering = ['start']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('events:detail', args=[self.pk])
