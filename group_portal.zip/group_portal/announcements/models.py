from django.conf import settings
from django.db import models


class Announcement(models.Model):
    title = models.CharField('Заголовок', max_length=200)
    body = models.TextField('Текст')
    pinned = models.BooleanField('Закріплено', default=False)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='announcements'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Оголошення'
        verbose_name_plural = 'Оголошення'
        ordering = ['-pinned', '-created_at']

    def __str__(self):
        return self.title
