from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from core.mixins import ModeratorRequiredMixin

from .forms import AnnouncementForm
from .models import Announcement


class AnnouncementListView(ListView):
    model = Announcement
    template_name = 'announcements/list.html'
    context_object_name = 'announcements'
    paginate_by = 10


class AnnouncementCreateView(ModeratorRequiredMixin, CreateView):
    model = Announcement
    form_class = AnnouncementForm
    template_name = 'announcements/form.html'
    success_url = reverse_lazy('announcements:list')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)


class AnnouncementUpdateView(ModeratorRequiredMixin, UpdateView):
    model = Announcement
    form_class = AnnouncementForm
    template_name = 'announcements/form.html'
    success_url = reverse_lazy('announcements:list')


class AnnouncementDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Announcement
    template_name = 'announcements/confirm_delete.html'
    success_url = reverse_lazy('announcements:list')
