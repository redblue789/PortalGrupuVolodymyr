from django.contrib.syndication.views import Feed
from django.urls import reverse

from .models import Announcement


class AnnouncementFeed(Feed):
    title = 'Оголошення — Портал групи'
    link = '/announcements/'
    description = 'Останні оголошення групи.'

    def items(self):
        return Announcement.objects.order_by('-created_at')[:20]

    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return item.body

    def item_link(self, item):
        return reverse('announcements:list') + f'#announcement-{item.pk}'
