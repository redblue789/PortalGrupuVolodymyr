from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from core.mixins import ModeratorRequiredMixin, OwnerOrModeratorMixin

from .forms import CategoryForm, PostForm, ThreadForm
from .models import Category, Post, Thread


class CategoryListView(ListView):
    model = Category
    template_name = 'forum/category_list.html'
    context_object_name = 'categories'


class CategoryDetailView(DetailView):
    model = Category
    template_name = 'forum/category_detail.html'
    context_object_name = 'category'


class CategoryCreateView(ModeratorRequiredMixin, CreateView):
    model = Category
    form_class = CategoryForm
    template_name = 'forum/category_form.html'
    success_url = reverse_lazy('forum:category_list')


class CategoryUpdateView(ModeratorRequiredMixin, UpdateView):
    model = Category
    form_class = CategoryForm
    template_name = 'forum/category_form.html'
    success_url = reverse_lazy('forum:category_list')


class CategoryDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Category
    template_name = 'forum/confirm_delete.html'
    success_url = reverse_lazy('forum:category_list')


class ThreadDetailView(DetailView):
    model = Thread
    template_name = 'forum/thread_detail.html'
    context_object_name = 'thread'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['posts'] = self.object.posts.select_related('author')
        ctx['post_form'] = PostForm()
        return ctx


class ThreadCreateView(LoginRequiredMixin, CreateView):
    model = Thread
    form_class = ThreadForm
    template_name = 'forum/thread_form.html'

    def form_valid(self, form):
        form.instance.category = get_object_or_404(Category, pk=self.kwargs['category_pk'])
        form.instance.author = self.request.user
        return super().form_valid(form)


class ThreadUpdateView(ModeratorRequiredMixin, UpdateView):
    model = Thread
    form_class = ThreadForm
    template_name = 'forum/thread_form.html'


class ThreadDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Thread
    template_name = 'forum/confirm_delete.html'

    def get_success_url(self):
        return self.object.category.get_absolute_url()


class PostCreateView(LoginRequiredMixin, CreateView):
    model = Post
    form_class = PostForm

    def post(self, request, *args, **kwargs):
        thread = get_object_or_404(Thread, pk=self.kwargs['thread_pk'])
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.thread = thread
            post.author = request.user
            post.save()
        return redirect(thread.get_absolute_url())


class PostDeleteView(OwnerOrModeratorMixin, DeleteView):
    model = Post
    template_name = 'forum/confirm_delete.html'

    def get_success_url(self):
        return self.object.thread.get_absolute_url()
