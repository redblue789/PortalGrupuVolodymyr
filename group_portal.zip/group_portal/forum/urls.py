from django.urls import path

from . import views

app_name = 'forum'

urlpatterns = [
    path('', views.CategoryListView.as_view(), name='category_list'),
    path('category/add/', views.CategoryCreateView.as_view(), name='category_add'),
    path('category/<int:pk>/', views.CategoryDetailView.as_view(), name='category_detail'),
    path('category/<int:pk>/edit/', views.CategoryUpdateView.as_view(), name='category_edit'),
    path('category/<int:pk>/delete/', views.CategoryDeleteView.as_view(), name='category_delete'),
    path('category/<int:category_pk>/thread/add/', views.ThreadCreateView.as_view(), name='thread_add'),
    path('thread/<int:pk>/', views.ThreadDetailView.as_view(), name='thread_detail'),
    path('thread/<int:pk>/edit/', views.ThreadUpdateView.as_view(), name='thread_edit'),
    path('thread/<int:pk>/delete/', views.ThreadDeleteView.as_view(), name='thread_delete'),
    path('thread/<int:thread_pk>/post/add/', views.PostCreateView.as_view(), name='post_add'),
    path('post/<int:pk>/delete/', views.PostDeleteView.as_view(), name='post_delete'),
]
