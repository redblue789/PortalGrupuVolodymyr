from django.conf import settings
from django.db import models
from django.urls import reverse


class Category(models.Model):
    """Гілка (розділ) форуму. Створюється лише модераторами/адміністраторами."""

    title = models.CharField('Назва', max_length=150)
    description = models.TextField('Опис', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Гілка форуму'
        verbose_name_plural = 'Гілки форуму'
        ordering = ['title']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('forum:category_detail', args=[self.pk])


class Thread(models.Model):
    """Тема обговорення всередині гілки форуму."""

    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='threads')
    title = models.CharField('Заголовок', max_length=200)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='forum_threads')
    created_at = models.DateTimeField(auto_now_add=True)
    is_pinned = models.BooleanField('Закріплено', default=False)

    class Meta:
        verbose_name = 'Тема'
        verbose_name_plural = 'Теми'
        ordering = ['-is_pinned', '-created_at']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('forum:thread_detail', args=[self.pk])


class Post(models.Model):
    """Повідомлення у темі. Може писати будь-який зареєстрований користувач."""

    thread = models.ForeignKey(Thread, on_delete=models.CASCADE, related_name='posts')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='forum_posts')
    content = models.TextField('Повідомлення')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Повідомлення'
        verbose_name_plural = 'Повідомлення'
        ordering = ['created_at']

    def __str__(self):
        return f'{self.author}: {self.content[:30]}'
