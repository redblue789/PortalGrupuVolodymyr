from django import forms

from .models import Category, Post, Thread


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ('title', 'description')

    def clean_title(self):
        title = self.cleaned_data['title'].strip()
        if len(title) < 3:
            raise forms.ValidationError('Назва гілки має містити щонайменше 3 символи.')
        return title


class ThreadForm(forms.ModelForm):
    class Meta:
        model = Thread
        fields = ('title',)

    def clean_title(self):
        title = self.cleaned_data['title'].strip()
        if len(title) < 5:
            raise forms.ValidationError('Заголовок теми має містити щонайменше 5 символів.')
        return title


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('content',)
        widgets = {'content': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Ваше повідомлення...'})}

    def clean_content(self):
        content = self.cleaned_data['content'].strip()
        if not content:
            raise forms.ValidationError('Повідомлення не може бути порожнім.')
        return content
