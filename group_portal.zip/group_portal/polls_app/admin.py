from django.contrib import admin

from .models import Answer, Choice, Poll, PollResponse, Question


class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 2


class QuestionInline(admin.StackedInline):
    model = Question
    extra = 1


@admin.register(Poll)
class PollAdmin(admin.ModelAdmin):
    list_display = ('title', 'is_active', 'question_count', 'created_at')
    inlines = [QuestionInline]


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('text', 'poll', 'question_type', 'order')
    inlines = [ChoiceInline]


admin.site.register(PollResponse)
admin.site.register(Answer)
