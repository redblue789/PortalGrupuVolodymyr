from django import forms

from .models import Choice, Poll, Question


class PollForm(forms.ModelForm):
    class Meta:
        model = Poll
        fields = ('title', 'description', 'is_active')


class QuestionForm(forms.ModelForm):
    """Форма додавання питання. Для питань з одним варіантом відповіді
    варіанти вказуються по одному на рядок у полі choices_text."""

    choices_text = forms.CharField(
        label='Варіанти відповіді (по одному на рядок)',
        widget=forms.Textarea(attrs={'rows': 4, 'placeholder': 'Варіант 1\nВаріант 2\nВаріант 3'}),
        required=False,
    )

    class Meta:
        model = Question
        fields = ('text', 'question_type', 'order', 'choices_text')

    def clean(self):
        cleaned = super().clean()
        if cleaned.get('question_type') == Question.SINGLE and not cleaned.get('choices_text', '').strip():
            raise forms.ValidationError('Для питання з вибором варіанту вкажіть хоча б один варіант відповіді.')
        return cleaned

    def save(self, commit=True):
        question = super().save(commit=commit)
        if commit and question.question_type == Question.SINGLE:
            question.choices.all().delete()
            for line in self.cleaned_data['choices_text'].splitlines():
                line = line.strip()
                if line:
                    Choice.objects.create(poll_question=question, text=line)
        return question


class SingleChoiceAnswerForm(forms.Form):
    choice = forms.ModelChoiceField(queryset=Choice.objects.none(), widget=forms.RadioSelect, label='')

    def __init__(self, *args, question=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['choice'].queryset = question.choices.all()


class TextAnswerForm(forms.Form):
    text_answer = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), label='', required=True)
