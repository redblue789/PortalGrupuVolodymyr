from django.urls import path

from . import views

app_name = 'polls_app'

urlpatterns = [
    path('', views.PollListView.as_view(), name='list'),
    path('add/', views.PollCreateView.as_view(), name='add'),
    path('<int:pk>/', views.PollDetailView.as_view(), name='detail'),
    path('<int:pk>/edit/', views.PollUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', views.PollDeleteView.as_view(), name='delete'),
    path('<int:pk>/manage/', views.PollManageView.as_view(), name='manage'),
    path('<int:poll_pk>/question/add/', views.QuestionCreateView.as_view(), name='question_add'),
    path('question/<int:pk>/delete/', views.QuestionDeleteView.as_view(), name='question_delete'),
    path('<int:pk>/take/', views.poll_take, name='take'),
    path('<int:pk>/submit/', views.poll_submit, name='submit'),
    path('<int:pk>/results/', views.PollResultsView.as_view(), name='results'),
]
