from django.conf import settings
from django.db import models
from django.urls import reverse


class Poll(models.Model):
    """Опитування. Може складатись з декількох сторінок (питань)."""

    title = models.CharField('Назва', max_length=200)
    description = models.TextField('Опис', blank=True)
    is_active = models.BooleanField('Активне', default=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='polls_created'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Опитування'
        verbose_name_plural = 'Опитування'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('polls_app:detail', args=[self.pk])

    @property
    def question_count(self):
        return self.questions.count()


class Question(models.Model):
    """Одне питання опитування = одна сторінка (етап) проходження."""

    TEXT = 'text'
    SINGLE = 'single'
    QUESTION_TYPES = [(SINGLE, 'Один варіант відповіді'), (TEXT, 'Текстова відповідь')]

    poll = models.ForeignKey(Poll, on_delete=models.CASCADE, related_name='questions')
    text = models.CharField('Питання', max_length=300)
    question_type = models.CharField(max_length=10, choices=QUESTION_TYPES, default=SINGLE)
    order = models.PositiveIntegerField('Порядок', default=0)

    class Meta:
        verbose_name = 'Питання'
        verbose_name_plural = 'Питання'
        ordering = ['order', 'id']

    def __str__(self):
        return self.text


class Choice(models.Model):
    poll_question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='choices')
    text = models.CharField('Варіант', max_length=200)

    class Meta:
        verbose_name = 'Варіант відповіді'
        verbose_name_plural = 'Варіанти відповіді'

    def __str__(self):
        return self.text


class PollResponse(models.Model):
    """Факт проходження опитування користувачем. Один запис на користувача
    (при повторному проходженні — старі відповіді видаляються та замінюються)."""

    poll = models.ForeignKey(Poll, on_delete=models.CASCADE, related_name='responses')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='poll_responses')
    submitted_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('poll', 'user')
        verbose_name = 'Проходження опитування'
        verbose_name_plural = 'Проходження опитувань'

    def __str__(self):
        return f'{self.user} -> {self.poll}'


class Answer(models.Model):
    response = models.ForeignKey(PollResponse, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='answers')
    choice = models.ForeignKey(Choice, on_delete=models.SET_NULL, null=True, blank=True)
    text_answer = models.TextField(blank=True)

    class Meta:
        verbose_name = 'Відповідь'
        verbose_name_plural = 'Відповіді'
