from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from core.mixins import ModeratorRequiredMixin

from .forms import PollForm, QuestionForm, SingleChoiceAnswerForm, TextAnswerForm
from .models import Answer, Choice, Poll, PollResponse, Question


class PollListView(ListView):
    model = Poll
    template_name = 'polls_app/poll_list.html'
    context_object_name = 'polls'

    def get_queryset(self):
        return Poll.objects.filter(is_active=True)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        if self.request.user.is_authenticated:
            ctx['completed_ids'] = set(
                PollResponse.objects.filter(user=self.request.user).values_list('poll_id', flat=True)
            )
        return ctx


class PollDetailView(DetailView):
    model = Poll
    template_name = 'polls_app/poll_detail.html'
    context_object_name = 'poll'


class PollCreateView(ModeratorRequiredMixin, CreateView):
    model = Poll
    form_class = PollForm
    template_name = 'polls_app/poll_form.html'

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('polls_app:manage', args=[self.object.pk])


class PollUpdateView(ModeratorRequiredMixin, UpdateView):
    model = Poll
    form_class = PollForm
    template_name = 'polls_app/poll_form.html'
    success_url = reverse_lazy('polls_app:list')


class PollDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Poll
    template_name = 'polls_app/confirm_delete.html'
    success_url = reverse_lazy('polls_app:list')


class PollManageView(ModeratorRequiredMixin, DetailView):
    """Сторінка керування питаннями опитування (додавання/перелік)."""

    model = Poll
    template_name = 'polls_app/poll_manage.html'
    context_object_name = 'poll'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['questions'] = self.object.questions.prefetch_related('choices')
        ctx['question_form'] = QuestionForm()
        return ctx


class QuestionCreateView(ModeratorRequiredMixin, CreateView):
    model = Question
    form_class = QuestionForm
    template_name = 'polls_app/question_form.html'

    def form_valid(self, form):
        form.instance.poll = get_object_or_404(Poll, pk=self.kwargs['poll_pk'])
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('polls_app:manage', args=[self.kwargs['poll_pk']])


class QuestionDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Question
    template_name = 'polls_app/confirm_delete.html'

    def get_success_url(self):
        return reverse('polls_app:manage', args=[self.object.poll_id])


@login_required
def poll_take(request, pk):
    """Багатоетапне проходження опитування: одне питання = одна сторінка.
    Прогрес зберігається у django.contrib.sessions, поки опитування не завершено.
    Користувач може пройти опитування лише раз; повторне проходження перезаписує
    попередній результат."""

    poll = get_object_or_404(Poll, pk=pk, is_active=True)
    questions = list(poll.questions.all())
    if not questions:
        messages.error(request, 'У цьому опитуванні ще немає питань.')
        return redirect('polls_app:list')

    session_key = f'poll_{poll.pk}_answers'
    progress = request.session.get(session_key, {})
    step = int(request.GET.get('step', 0))
    step = max(0, min(step, len(questions) - 1))
    question = questions[step]

    FormClass = SingleChoiceAnswerForm if question.question_type == Question.SINGLE else TextAnswerForm
    form_kwargs = {'question': question} if question.question_type == Question.SINGLE else {}

    if request.method == 'POST':
        form = FormClass(request.POST, **form_kwargs)
        if form.is_valid():
            if question.question_type == Question.SINGLE:
                progress[str(question.pk)] = {'choice_id': form.cleaned_data['choice'].pk}
            else:
                progress[str(question.pk)] = {'text': form.cleaned_data['text_answer']}
            request.session[session_key] = progress
            request.session.modified = True

            if step + 1 < len(questions):
                return redirect(f"{reverse('polls_app:take', args=[poll.pk])}?step={step + 1}")
            return redirect('polls_app:submit', pk=poll.pk)
    else:
        initial = {}
        saved = progress.get(str(question.pk))
        if saved:
            initial = {'choice': saved.get('choice_id')} if 'choice_id' in saved else {'text_answer': saved.get('text')}
        form = FormClass(initial=initial, **form_kwargs)

    return render(request, 'polls_app/poll_take.html', {
        'poll': poll, 'question': question, 'form': form,
        'step': step, 'total': len(questions), 'progress_pct': round((step + 1) / len(questions) * 100),
    })


@login_required
def poll_submit(request, pk):
    """Записує накопичені у сесії відповіді в базу даних (перезаписуючи попередній
    результат користувача, якщо він вже проходив опитування) і очищує сесію."""

    poll = get_object_or_404(Poll, pk=pk)
    session_key = f'poll_{poll.pk}_answers'
    progress = request.session.get(session_key, {})

    response, _ = PollResponse.objects.get_or_create(poll=poll, user=request.user)
    response.answers.all().delete()
    for question in poll.questions.all():
        saved = progress.get(str(question.pk))
        if not saved:
            continue
        if 'choice_id' in saved:
            Answer.objects.create(
                response=response, question=question,
                choice_id=saved['choice_id'],
            )
        else:
            Answer.objects.create(response=response, question=question, text_answer=saved.get('text', ''))

    if session_key in request.session:
        del request.session[session_key]
    messages.success(request, 'Дякуємо! Ваші відповіді збережено.')
    return redirect('polls_app:list')


class PollResultsView(ModeratorRequiredMixin, DetailView):
    """Зручний перегляд агрегованих результатів опитування для модераторів/адмінів."""

    model = Poll
    template_name = 'polls_app/poll_results.html'
    context_object_name = 'poll'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        questions_data = []
        for question in self.object.questions.prefetch_related('choices', 'answers'):
            if question.question_type == Question.SINGLE:
                counts = []
                for choice in question.choices.all():
                    counts.append((choice.text, choice.answer_set.count()))
                questions_data.append({'question': question, 'type': 'single', 'counts': counts})
            else:
                texts = list(question.answers.exclude(text_answer='').values_list('text_answer', flat=True))
                questions_data.append({'question': question, 'type': 'text', 'texts': texts})
        ctx['questions_data'] = questions_data
        ctx['respondents_count'] = self.object.responses.count()
        return ctx
