from django.urls import path

from . import views

app_name = 'voting'

urlpatterns = [
    path('', views.VoteListView.as_view(), name='list'),
    path('add/', views.VoteCreateView.as_view(), name='add'),
    path('<int:pk>/', views.VoteDetailView.as_view(), name='detail'),
    path('<int:pk>/edit/', views.VoteUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', views.VoteDeleteView.as_view(), name='delete'),
    path('<int:pk>/manage/', views.VoteManageView.as_view(), name='manage'),
    path('<int:vote_pk>/option/add/', views.VoteOptionCreateView.as_view(), name='option_add'),
    path('option/<int:pk>/delete/', views.VoteOptionDeleteView.as_view(), name='option_delete'),
    path('<int:pk>/cast/', views.cast_ballot, name='cast'),
]
