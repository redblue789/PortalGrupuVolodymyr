from django.contrib import admin

from .models import Ballot, Vote, VoteOption


class VoteOptionInline(admin.TabularInline):
    model = VoteOption
    extra = 2


@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ('title', 'is_active', 'total_ballots', 'created_at')
    inlines = [VoteOptionInline]


admin.site.register(Ballot)
