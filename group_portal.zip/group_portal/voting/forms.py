from django import forms

from .models import Vote, VoteOption


class VoteForm(forms.ModelForm):
    class Meta:
        model = Vote
        fields = ('title', 'description', 'is_active')


class VoteOptionForm(forms.ModelForm):
    class Meta:
        model = VoteOption
        fields = ('text',)


class BallotForm(forms.Form):
    option = forms.ModelChoiceField(queryset=VoteOption.objects.none(), widget=forms.RadioSelect, label='')

    def __init__(self, *args, vote=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['option'].queryset = vote.options.all()
