from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from core.mixins import ModeratorRequiredMixin

from .forms import BallotForm, VoteForm, VoteOptionForm
from .models import Ballot, Vote, VoteOption


class VoteListView(ListView):
    model = Vote
    template_name = 'voting/vote_list.html'
    context_object_name = 'votes'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        if self.request.user.is_authenticated:
            ctx['voted_ids'] = set(Ballot.objects.filter(user=self.request.user).values_list('vote_id', flat=True))
        return ctx


class VoteCreateView(ModeratorRequiredMixin, CreateView):
    model = Vote
    form_class = VoteForm
    template_name = 'voting/vote_form.html'

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('voting:manage', kwargs={'pk': self.object.pk})


class VoteUpdateView(ModeratorRequiredMixin, UpdateView):
    model = Vote
    form_class = VoteForm
    template_name = 'voting/vote_form.html'
    success_url = reverse_lazy('voting:list')


class VoteDeleteView(ModeratorRequiredMixin, DeleteView):
    model = Vote
    template_name = 'voting/confirm_delete.html'
    success_url = reverse_lazy('voting:list')


class VoteManageView(ModeratorRequiredMixin, DetailView):
    model = Vote
    template_name = 'voting/vote_manage.html'
    context_object_name = 'vote'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['option_form'] = VoteOptionForm()
        return ctx


class VoteOptionCreateView(ModeratorRequiredMixin, CreateView):
    model = VoteOption
    form_class = VoteOptionForm
    template_name = 'voting/option_form.html'

    def form_valid(self, form):
        form.instance.vote = get_object_or_404(Vote, pk=self.kwargs['vote_pk'])
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('voting:manage', kwargs={'pk': self.kwargs['vote_pk']})


class VoteOptionDeleteView(ModeratorRequiredMixin, DeleteView):
    model = VoteOption
    template_name = 'voting/confirm_delete.html'

    def get_success_url(self):
        return reverse_lazy('voting:manage', kwargs={'pk': self.object.vote_id})


class VoteDetailView(DetailView):
    """Перегляд голосування: форма голосування (для не голосувавших) +
    результати, доступні всім користувачам."""

    model = Vote
    template_name = 'voting/vote_detail.html'
    context_object_name = 'vote'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        options = self.object.options.all()
        total = self.object.total_ballots or 1
        ctx['results'] = [
            {'option': o, 'count': o.ballot_count, 'pct': round(o.ballot_count / total * 100, 1)}
            for o in options
        ]
        if self.request.user.is_authenticated:
            ctx['user_ballot'] = Ballot.objects.filter(vote=self.object, user=self.request.user).first()
            ctx['form'] = BallotForm(vote=self.object)
        return ctx


@login_required
def cast_ballot(request, pk):
    vote = get_object_or_404(Vote, pk=pk, is_active=True)
    if request.method == 'POST':
        form = BallotForm(request.POST, vote=vote)
        if form.is_valid():
            Ballot.objects.update_or_create(
                vote=vote, user=request.user, defaults={'option': form.cleaned_data['option']}
            )
            messages.success(request, 'Ваш голос враховано.')
    return redirect('voting:detail', pk=pk)
