from django.conf import settings
from django.db import models
from django.urls import reverse


class Vote(models.Model):
    """Голосування з декількома варіантами відповіді."""

    title = models.CharField('Назва', max_length=200)
    description = models.TextField('Опис', blank=True)
    is_active = models.BooleanField('Активне', default=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='votes_created'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Голосування'
        verbose_name_plural = 'Голосування'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('voting:detail', args=[self.pk])

    @property
    def total_ballots(self):
        return self.ballots.count()


class VoteOption(models.Model):
    vote = models.ForeignKey(Vote, on_delete=models.CASCADE, related_name='options')
    text = models.CharField('Варіант', max_length=200)

    class Meta:
        verbose_name = 'Варіант голосування'
        verbose_name_plural = 'Варіанти голосування'

    def __str__(self):
        return self.text

    @property
    def ballot_count(self):
        return self.ballots.count()


class Ballot(models.Model):
    """Голос користувача. Один голос на голосування — при повторному
    голосуванні зберігається лише останній вибір."""

    vote = models.ForeignKey(Vote, on_delete=models.CASCADE, related_name='ballots')
    option = models.ForeignKey(VoteOption, on_delete=models.CASCADE, related_name='ballots')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='ballots')
    voted_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('vote', 'user')
        verbose_name = 'Голос'
        verbose_name_plural = 'Голоси'
