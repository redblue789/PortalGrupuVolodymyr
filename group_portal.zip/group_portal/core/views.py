from django.views.generic import TemplateView

from announcements.models import Announcement
from events.models import Event
from forum.models import Post, Thread
from gallery.models import GalleryItem
from materials.models import Material
from portfolio.models import PortfolioItem
from django.utils import timezone


class HomeView(TemplateView):
    """Головна сторінка: загальна інформація про групу
    + сніпети (віджети) з інших розділів сайту."""

    template_name = 'core/home.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['announcements'] = Announcement.objects.order_by('-pinned', '-created_at')[:3]
        ctx['events'] = Event.objects.filter(start__gte=timezone.now()).order_by('start')[:3]
        ctx['threads'] = Thread.objects.order_by('-created_at')[:5]
        ctx['gallery_items'] = GalleryItem.objects.filter(is_approved=True).order_by('-created_at')[:6]
        return ctx


class AboutView(TemplateView):
    template_name = 'core/about.html'


class SearchView(TemplateView):
    """Глобальний пошук по темах форуму, повідомленнях, матеріалах,
    оголошеннях та портфоліо."""

    template_name = 'core/search.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        query = self.request.GET.get('q', '').strip()
        ctx['query'] = query
        if query:
            ctx['threads'] = Thread.objects.filter(title__icontains=query)[:10]
            ctx['posts'] = Post.objects.filter(content__icontains=query).select_related('thread')[:10]
            ctx['materials'] = Material.objects.filter(title__icontains=query)[:10]
            ctx['announcements'] = Announcement.objects.filter(title__icontains=query)[:10]
            ctx['portfolio_items'] = PortfolioItem.objects.filter(title__icontains=query)[:10]
            ctx['total'] = (
                len(ctx['threads']) + len(ctx['posts']) + len(ctx['materials'])
                + len(ctx['announcements']) + len(ctx['portfolio_items'])
            )
        return ctx


class DashboardView(TemplateView):
    """Проста статистична панель для адміністраторів/модераторів."""

    template_name = 'core/dashboard.html'

    def dispatch(self, request, *args, **kwargs):
        profile = getattr(request.user, 'profile', None)
        if not (request.user.is_authenticated and profile and profile.is_moderator):
            from django.contrib.auth.views import redirect_to_login
            return redirect_to_login(request.get_full_path())
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        from django.contrib.auth.models import User
        from diary.models import Grade
        from forum.models import Thread
        from polls_app.models import Poll
        from voting.models import Vote

        ctx = super().get_context_data(**kwargs)
        ctx['users_count'] = User.objects.count()
        ctx['threads_count'] = Thread.objects.count()
        ctx['grades_count'] = Grade.objects.count()
        ctx['materials_count'] = Material.objects.count()
        ctx['polls_count'] = Poll.objects.filter(is_active=True).count()
        ctx['votes_count'] = Vote.objects.filter(is_active=True).count()
        ctx['pending_gallery'] = GalleryItem.objects.filter(is_approved=False).count()
        ctx['events_count'] = Event.objects.filter(start__gte=timezone.now()).count()
        return ctx
