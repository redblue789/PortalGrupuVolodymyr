"""
Спільні міксини контролю доступу на основі ролей (user / moderator / admin).
Використовуються у всіх застосунках проекту.
"""

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin


class RoleRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Базовий міксин: дозволяє доступ лише користувачам з профілем,
    роль якого входить у required_roles."""

    required_roles = ()
    raise_exception = False

    def test_func(self):
        user = self.request.user
        if not user.is_authenticated:
            return False
        profile = getattr(user, 'profile', None)
        if profile is None:
            return False
        return profile.role in self.required_roles or user.is_superuser


class ModeratorRequiredMixin(RoleRequiredMixin):
    """Доступ для модераторів та адміністраторів."""
    required_roles = ('moderator', 'admin')


class AdminRequiredMixin(RoleRequiredMixin):
    """Доступ лише для адміністраторів."""
    required_roles = ('admin',)


class OwnerOrModeratorMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Дозволяє доступ автору об'єкта, або модератору/адміністратору.
    Очікує, що у View визначено owner_field (за замовч. 'user')."""

    owner_field = 'user'

    def test_func(self):
        obj = self.get_object()
        user = self.request.user
        if not user.is_authenticated:
            return False
        if getattr(obj, self.owner_field + '_id', None) == user.id:
            return True
        profile = getattr(user, 'profile', None)
        if profile and profile.role in ('moderator', 'admin'):
            return True
        return user.is_superuser
