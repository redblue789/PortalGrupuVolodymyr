from django.core.management.base import BaseCommand

from announcements.models import Announcement
from diary.models import Subject
from forum.models import Category
from voting.models import Vote, VoteOption
from polls_app.models import Poll, Question, Choice


class Command(BaseCommand):
    help = 'Наповнює портал демонстраційними даними (предмети, гілка форуму, оголошення, опитування, голосування).'

    def handle(self, *args, **options):
        subjects = ['Математика', 'Програмування', 'Англійська мова', 'Фізика']
        for name in subjects:
            Subject.objects.get_or_create(name=name)
        self.stdout.write(self.style.SUCCESS(f'Предмети: {len(subjects)} шт.'))

        Category.objects.get_or_create(
            title='Загальні питання',
            defaults={'description': 'Обговорення навчального процесу та організаційних питань.'},
        )
        self.stdout.write(self.style.SUCCESS('Гілку форуму "Загальні питання" створено.'))

        Announcement.objects.get_or_create(
            title='Ласкаво просимо на портал групи!',
            defaults={'body': 'Тут ви знайдете новини групи, оцінки, події, форум та інші розділи порталу.', 'pinned': True},
        )
        self.stdout.write(self.style.SUCCESS('Вітальне оголошення створено.'))

        poll, poll_created = Poll.objects.get_or_create(
            title='Опитування про зручність порталу',
            defaults={'description': 'Допоможіть нам покращити портал групи.'},
        )
        if poll_created:
            q1 = Question.objects.create(poll=poll, text='Наскільки зручний портал?', question_type=Question.SINGLE, order=1)
            for text in ['Дуже зручний', 'Загалом зручний', 'Потребує покращень']:
                Choice.objects.create(poll_question=q1, text=text)
            Question.objects.create(poll=poll, text='Що б ви хотіли додати на портал?', question_type=Question.TEXT, order=2)
        self.stdout.write(self.style.SUCCESS('Демонстраційне опитування створено.'))

        vote, vote_created = Vote.objects.get_or_create(
            title='Вибір старости групи',
            defaults={'description': 'Голосування за кандидата на посаду старости групи.'},
        )
        if vote_created:
            for text in ['Кандидат А', 'Кандидат Б', 'Утримався']:
                VoteOption.objects.create(vote=vote, text=text)
        self.stdout.write(self.style.SUCCESS('Демонстраційне голосування створено.'))

        self.stdout.write(self.style.SUCCESS('Готово! Демонстраційні дані додано.'))
