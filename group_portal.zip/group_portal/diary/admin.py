from django.contrib import admin

from .models import Grade, Subject

admin.site.register(Subject)


@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ('student', 'subject', 'value', 'date')
    list_filter = ('subject',)
