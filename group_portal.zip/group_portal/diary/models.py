from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models


class Subject(models.Model):
    """Навчальний предмет."""

    name = models.CharField('Назва предмету', max_length=100, unique=True)

    class Meta:
        verbose_name = 'Предмет'
        verbose_name_plural = 'Предмети'
        ordering = ['name']

    def __str__(self):
        return self.name


class Grade(models.Model):
    """Оцінка студента з предмету (шкала 1-12)."""

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='grades'
    )
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='grades')
    value = models.PositiveSmallIntegerField(
        'Оцінка', validators=[MinValueValidator(1), MaxValueValidator(12)]
    )
    date = models.DateField('Дата')
    comment = models.CharField('Коментар', max_length=200, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='grades_given'
    )

    class Meta:
        verbose_name = 'Оцінка'
        verbose_name_plural = 'Оцінки'
        ordering = ['-date']

    def __str__(self):
        return f'{self.student} — {self.subject}: {self.value}'
