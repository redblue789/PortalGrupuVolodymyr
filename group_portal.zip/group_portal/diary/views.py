from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from core.mixins import AdminRequiredMixin

from .forms import GradeForm
from .models import Grade, Subject


class MyGradesView(LoginRequiredMixin, ListView):
    """Учень бачить власні оцінки з усіх предметів."""

    model = Grade
    template_name = 'diary/my_grades.html'
    context_object_name = 'grades'

    def get_queryset(self):
        return Grade.objects.filter(student=self.request.user).select_related('subject')


class AllGradesView(AdminRequiredMixin, ListView):
    """Адміністратор бачить оцінки усіх студентів у зручній таблиці."""

    template_name = 'diary/all_grades.html'
    context_object_name = 'grades'

    def get_queryset(self):
        return Grade.objects.select_related('student', 'subject').order_by('student__username', '-date')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['students'] = User.objects.filter(profile__isnull=False).order_by('username')
        ctx['subjects'] = Subject.objects.all()
        return ctx


class GradeCreateView(AdminRequiredMixin, CreateView):
    model = Grade
    form_class = GradeForm
    template_name = 'diary/grade_form.html'
    success_url = reverse_lazy('diary:all_grades')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)


class GradeUpdateView(AdminRequiredMixin, UpdateView):
    model = Grade
    form_class = GradeForm
    template_name = 'diary/grade_form.html'
    success_url = reverse_lazy('diary:all_grades')


class GradeDeleteView(AdminRequiredMixin, DeleteView):
    model = Grade
    template_name = 'diary/confirm_delete.html'
    success_url = reverse_lazy('diary:all_grades')


def export_grades_csv(request):
    """Експорт усіх оцінок групи у форматі CSV (лише для адміністраторів)."""
    profile = getattr(request.user, 'profile', None)
    if not (request.user.is_authenticated and profile and profile.is_admin_role):
        return HttpResponse('Недостатньо прав.', status=403)

    import csv

    response = HttpResponse(content_type='text/csv; charset=utf-8')
    response['Content-Disposition'] = 'attachment; filename="grades.csv"'
    response.write('\ufeff')  # BOM для коректного відкриття кирилиці в Excel
    writer = csv.writer(response)
    writer.writerow(['Учень', 'Предмет', 'Оцінка', 'Дата', 'Коментар'])
    for g in Grade.objects.select_related('student', 'subject').order_by('student__username', '-date'):
        writer.writerow([g.student.username, g.subject.name, g.value, g.date, g.comment])
    return response
