from django.urls import path

from . import views

app_name = 'diary'

urlpatterns = [
    path('', views.MyGradesView.as_view(), name='my_grades'),
    path('all/', views.AllGradesView.as_view(), name='all_grades'),
    path('add/', views.GradeCreateView.as_view(), name='grade_add'),
    path('<int:pk>/edit/', views.GradeUpdateView.as_view(), name='grade_edit'),
    path('<int:pk>/delete/', views.GradeDeleteView.as_view(), name='grade_delete'),
    path('export/csv/', views.export_grades_csv, name='export_csv'),
]
